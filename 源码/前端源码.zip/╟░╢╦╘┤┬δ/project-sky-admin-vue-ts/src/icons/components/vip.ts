/* eslint-disable */
/* tslint:disable */
// @ts-ignore
import icon from 'vue-svgicon'
icon.register({
  'vip': {
    width: 62,
    height: 62,
    viewBox: '0 0 62 62',
    data: '<image width="62" height="62" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAAA+CAMAAABEH1h2AAAABGdBTUEAALGPC/xhBQAAACBjSFJN AAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAB1FBMVEX///////////////// //////////////////////////////////////////////////////////////////////////// //////////////////////////////////////////////////////////////////////////// //////////////////////////////////////////////////////////////////////////// //////////////////////////////////////////////////////////////////////////// //////////////////////////////////////////////////////////////////////////// //////////////////////////////////////////////////////////////////////////// //////////////////////////////////////////////////////////////////////////// ////////////////kEP/kT//kT7/kj//v0D/kT7/kj//kT7/kT//mU3/kj7/kT7/kz7/////kD3j blauAAAAmnRSTlMAQ10Yn+8rJKcB5v5CN2zJ5wpg93kNg2MQAk9iF4rjA9mGD15XB7XtIyX5WVb0 E+DMNpC0w86Tc1Q72ilJ/TEgxljFqAXYmsKgNKoMCI0sFTz8vtat8W+2x9LzgmuxBDD6oi3ETG2v L3qOHfWjdnA6fOFlq3VE0ECW+2HU5HEaacBQ3DOF+FXdyB+SpiIXgpBuBKxpoF0KYm9Or+9urQAA AAFiS0dEAIgFHUgAAAAHdElNRQfjDAwSHg7/efTzAAAB9klEQVRIx+2UZ1cTQRSGRyURXRGCoqJI MBpEVMReQkARUREUC/YCKmDvvYCIvffy+GeZybLmeA53hrN+4OjJ+2Uz7zvPzN3Zm1Eqp5z+L40b P+Ev6DyIREPTE9HKC41HDZ4fGp80GbwpofECT+8+NfTmhab4olhIvBim6fKnh6NLimDGTP3pZo0S KJ09pyw7mgvlsXgFzMt6ifkLkuK7VsLCqmC0qBoWK7UElv5es2YZ1Er8cnNSK4LRSlhl1lwNawJv rZmxTsDXm3BDyh/UQbp++Ed1g+9VbTQzNgl4vNGk6c2my5u2QLNvb4Vt5rm9JZ1Zf4f08q1tJsdr 2WnKjOzy3XbYnVJ1ezIZexPy0Sc8f463rwP2B+4BOHgo4x+GI7ZPp0s+emx4m+OBeSJTNJ1dJ0/B aRveBd2qvkcX0dGbdc+Yjc+eU/HzUGbDu+GCfkQvXvpj2uUrxab1euGqjVYFUCGn1+C6FU924slH 2ww3rLiqhZtieAtu2/E7lj9o7C7pEjt+D3qkTDf1fTttbscHUvbQfe2W6sbqE7J86Hfg6hEMCNFj GHTh+o55MnJSA0+bXPgz3Z/PR1Q5vHDR6iUWvXLi6rVMR1JuXPW9kZQcBT22evvuvaQPH934p1+y PrvxLxb8qxv/9v2HpJ9jfbA55fSvawjYwxb1SCPMxAAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAxOS0x Mi0xMlQxMDozMDoxNCswODowMDx7RY0AAAAldEVYdGRhdGU6bW9kaWZ5ADIwMTktMTItMTJUMTA6 MzA6MTQrMDg6MDBNJv0xAAAAAElFTkSuQmCC"/>'
  }
})
