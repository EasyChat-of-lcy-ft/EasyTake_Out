/* eslint-disable */
/* tslint:disable */
// @ts-ignore
import icon from 'vue-svgicon'
icon.register({
  'dashboard': {
    width: 32,
    height: 32,
    viewBox: '0 0 1024 1024',
    data: '<path pid="4758" d="M888 462.4L544 142.4c-19.2-17.6-48-17.6-65.6 0l-344 320c-9.6 9.6-16 22.4-16 35.2v355.2c0 27.2 22.4 49.6 49.6 49.6h240V657.6c0-56 46.4-102.4 102.4-102.4 56 0 102.4 46.4 102.4 102.4v246.4h240c27.2 0 49.6-22.4 49.6-49.6V497.6c1.6-12.8-4.8-25.6-14.4-35.2z"/>'
  }
})
